﻿using System.Globalization;

namespace CalculatriceApp;

public partial class MainPage : ContentPage
{
    // Les opérateurs sont ecrits avec des echappements Unicode pour eviter
    // toute re-encodage du fichier (ils doivent correspondre au Text des boutons).
    private const string OpAdd = "+";
    private const string OpSub = "\u2212";   // −
    private const string OpMul = "\u00D7";   // ×
    private const string OpDiv = "\u00F7";   // ÷

    private string _currentInput = "0";
    private double _previousValue = 0;
    private string? _pendingOperator = null;
    private bool _startNewInput = true;

    // Vrai quand un signe moins vient d'etre applique : il doit etre reporte
    // sur le prochain nombre saisi (comportement des calculatrices iOS/Windows).
    private bool _negateNextEntry = false;

    public MainPage()
    {
        InitializeComponent();
    }

    // ---- Saisie des chiffres et du point decimal ----

    private void OnDigitClicked(object? sender, EventArgs e)
    {
        string digit = ((sender as Button)?.Text) ?? string.Empty;
        if (digit.Length == 0)
            return;

        if (_startNewInput)
        {
            _currentInput = digit;
            _startNewInput = false;
        }
        else
        {
            _currentInput = _currentInput == "0" ? digit : _currentInput + digit;
        }

        if (_negateNextEntry)
        {
            _currentInput = _currentInput.StartsWith('-') ? _currentInput[1..] : "-" + _currentInput;
            _negateNextEntry = false;
        }

        ResultLabel.Text = _currentInput;
    }

    private void OnDecimalClicked(object? sender, EventArgs e)
    {
        if (_startNewInput)
        {
            _currentInput = "0.";
            _startNewInput = false;
        }
        else if (!_currentInput.Contains('.'))
        {
            _currentInput += ".";
        }

        if (_negateNextEntry)
        {
            _currentInput = _currentInput.StartsWith('-') ? _currentInput[1..] : "-" + _currentInput;
            _negateNextEntry = false;
        }

        ResultLabel.Text = _currentInput;
    }

    // ---- Operateurs et calcul ----

    private void OnOperatorClicked(object? sender, EventArgs e)
    {
        string op = ((sender as Button)?.Text) ?? string.Empty;
        if (op.Length == 0)
            return;

        if (_pendingOperator != null && !_startNewInput)
        {
            if (!Calculate())
                return;
        }
        else
        {
            _previousValue = ParseCurrentInput();
        }

        _pendingOperator = op;
        _negateNextEntry = false;
        OperationLabel.Text = $"{FormatNumber(_previousValue)} {op}";
        _startNewInput = true;
    }

    private void OnEqualsClicked(object? sender, EventArgs e)
    {
        if (_pendingOperator == null)
            return;

        OperationLabel.Text = $"{FormatNumber(_previousValue)} {_pendingOperator} {_currentInput} =";
        Calculate();
        _pendingOperator = null;
        _negateNextEntry = false;
        _startNewInput = true;
    }

    private bool Calculate()
    {
        double current = ParseCurrentInput();
        double result;

        switch (_pendingOperator)
        {
            case OpAdd:
                result = _previousValue + current;
                break;
            case OpSub:
                result = _previousValue - current;
                break;
            case OpMul:
                result = _previousValue * current;
                break;
            case OpDiv:
                if (current == 0)
                {
                    ShowDivisionByZeroError();
                    return false;
                }
                result = _previousValue / current;
                break;
            default:
                result = current;
                break;
        }

        _previousValue = result;
        _currentInput = FormatNumber(result);
        ResultLabel.Text = _currentInput;
        return true;
    }

    private void ShowDivisionByZeroError()
    {
        ResultLabel.Text = "Erreur";
        OperationLabel.Text = "Division par zéro";
        _currentInput = "0";
        _previousValue = 0;
        _pendingOperator = null;
        _negateNextEntry = false;
        _startNewInput = true;
    }

    // ---- Fonctions utilitaires (AC, effacer, +/-, %) ----

    private void OnClearClicked(object? sender, EventArgs e)
    {
        _currentInput = "0";
        _previousValue = 0;
        _pendingOperator = null;
        _startNewInput = true;
        _negateNextEntry = false;
        ResultLabel.Text = "0";
        OperationLabel.Text = " ";
    }

    private void OnBackspaceClicked(object? sender, EventArgs e)
    {
        // Inert juste apres un operateur ou un "=" (rien n'est en cours de saisie),
        // mais actif apres un "+/-" pour annuler la saisie.
        if (_startNewInput && !_negateNextEntry)
            return;

        _startNewInput = false;
        _negateNextEntry = false;

        _currentInput = _currentInput.Length > 1
            ? _currentInput[..^1]
            : "0";

        // Un effacement peut laisser un fragment non numerique ("-", ".") :
        // on retombe alors sur zero pour garantir une saisie toujours analysable.
        if (!IsValidNumber(_currentInput))
            _currentInput = "0";

        ResultLabel.Text = _currentInput;
    }

    private void OnSignClicked(object? sender, EventArgs e)
    {
        _currentInput = FormatNumber(-ParseCurrentInput());

        // Le nombre saisi est desormais complet : le chiffre suivant demarre
        // un nouveau nombre, en conservant le signe qui vient d'etre pose.
        _startNewInput = true;
        _negateNextEntry = true;

        ResultLabel.Text = _currentInput;
    }

    private void OnPercentClicked(object? sender, EventArgs e)
    {
        double value = ParseCurrentInput();

        // Semantique iOS / Windows : "A + B%" vaut A + A*B/100.
        // Pour "x" et "/", le pourcentage se limite a une conversion en fraction.
        _currentInput = FormatNumber(
            _pendingOperator is OpAdd or OpSub
                ? _previousValue * value / 100.0
                : value / 100.0);

        ResultLabel.Text = _currentInput;
    }

    // ---- Aides de conversion (independantes de la langue du telephone) ----

    private double ParseCurrentInput()
    {
        return double.TryParse(_currentInput, NumberStyles.Float, CultureInfo.InvariantCulture, out double value)
            ? value
            : 0;
    }

    private static bool IsValidNumber(string text)
    {
        return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out _);
    }

    private static string FormatNumber(double value)
    {
        // Le cas 0 doit preceder le test modulo, sinon -0 s'affiche "-0".
        if (value == 0)
            return "0";

        return value % 1 == 0
            ? value.ToString("0", CultureInfo.InvariantCulture)
            : value.ToString("0.##########", CultureInfo.InvariantCulture);
    }
}
