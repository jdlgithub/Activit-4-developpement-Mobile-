using Foundation;

namespace CalculatriceApp;

[Register("SceneDelegate")]
public class SceneDelegate : MauiUISceneDelegate
{
}
